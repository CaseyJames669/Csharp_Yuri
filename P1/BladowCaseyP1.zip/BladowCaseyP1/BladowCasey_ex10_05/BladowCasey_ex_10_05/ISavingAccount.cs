﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BladowCasey_ex_10_05
{
    public interface ISavingAccount
    {
        void CalculateMonthlyInterest();
        string ToString();
    }
}
