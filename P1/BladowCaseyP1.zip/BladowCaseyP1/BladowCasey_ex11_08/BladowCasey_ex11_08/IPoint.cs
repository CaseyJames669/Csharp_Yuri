﻿using System;
namespace BladowCasey_ex11_08
{
    interface IPoint
    {
        string ToString();
        double X { get; }
        double Y { get; }
    }
}
