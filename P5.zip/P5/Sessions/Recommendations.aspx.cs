﻿// Fig. 23.30: Recommendations.aspx.cs
// Creates book recommendations based on a Session object.
using System;

public partial class Recommendations : System.Web.UI.Page
{
   // read Session items and populate ListBox with recommendations
   protected void Page_Init(object sender, EventArgs e)
   {
      // determine whether Session contains any information
      if ()
      {
         // display Session's name-value pairs
         
      } // end if
      else
      {
         // if there are no session items, no language was chosen, so
         // display appropriate message and clear and hide booksListBox
         recommendationsLabel.Text = "No Recommendations";
         booksListBox.Visible = false;

         // modify languageLink because no language was selected
         languageLink.Text = "Click here to choose a language";
      } // end else
   } // end method Page_Init
} // end class Recommendations

